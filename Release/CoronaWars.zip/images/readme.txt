images from pixabay.com.


Images and Videos on Pixabay are released under Creative Commons CC0. To the extent possible under law, uploaders of Pixabay have waived their copyright and related or neighboring rights to these Images and Videos. You are free to adapt and use them for commercial purposes without attributing the original author or source. Although not required, a link back to Pixabay is appreciated.

Please be aware:

a) Imagery depicting identifiable persons, logos, brands, etc. may be subject to additional copyrights, property rights, privacy rights, trademarks etc. and may require the consent of a third party or the license of these rights - particularly for commercial applications.

b) Images and Videos may not be used in a way that shows identifiable persons in a disgraceful light, or to imply endorsement of products and services by depicted persons, brands, and organisations - unless permission was granted.
